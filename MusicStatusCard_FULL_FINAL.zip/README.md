# Music Status Card — Android Project

## Included
- Photo picker
- Local audio picker
- MP3/audio metadata extraction (title, artist, duration)
- Embedded album-art extraction when present in the audio file
- Three WhatsApp-inspired music-card styles
- 1080x1920 (9:16) status-card PNG rendering
- Android share sheet for sending the generated card to WhatsApp or another app
- No WhatsApp APK modification is required

## Build
Open the project root in Android Studio (recent stable version), let Gradle sync, then:
Build -> Build APK(s)

The APK is generated under:
app/build/outputs/apk/debug/

## Important
This project intentionally does not redistribute Spotify audio or modify WhatsApp. A Spotify integration can be added using Spotify's official OAuth/Web API for permitted metadata/artwork, but it requires a Spotify developer application/client configuration and should follow Spotify's current policies.

The selected local audio is used for metadata/card information. The current export is a visual PNG card; it does not synthesize an MP4 with the selected audio.

## App flow
Photo -> Song -> Card style -> Create & Share Status Card.
