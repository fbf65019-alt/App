package com.musicstatus.card

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.OutputStream

data class SongInfo(
    val title: String = "My Song",
    val artist: String = "Unknown Artist",
    val album: String = "",
    val durationMs: Long = 0L
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var photo by remember { mutableStateOf<Uri?>(null) }
    var song by remember { mutableStateOf<Uri?>(null) }
    var info by remember { mutableStateOf(SongInfo()) }
    var style by remember { mutableIntStateOf(0) }
    var cover by remember { mutableStateOf<Bitmap?>(null) }
    var status by remember { mutableStateOf("") }

    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        photo = uri
        status = if (uri != null) "Photo selected" else ""
    }
    val audioPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        song = uri
        if (uri != null) {
            info = readSongInfo(context.contentResolver, uri)
            cover = extractAlbumArt(context.contentResolver, uri)
            status = "Song selected"
        }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            containerColor = Color(0xFF0B0B0B),
            topBar = {
                TopAppBar(
                    title = { Text("Music Status Card", fontWeight = FontWeight.Bold) },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF0B0B0B),
                        titleContentColor = Color.White
                    )
                )
            }
        ) { pad ->
            Column(
                Modifier.fillMaxSize().padding(pad).padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                StatusPreview(photo, cover, info, style)
                Spacer(Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { photoPicker.launch("image/*") }) { Text("Photo") }
                    Button(onClick = { audioPicker.launch("audio/*") }) { Text("Song") }
                }

                Spacer(Modifier.height(10.dp))
                Text("Choose music card", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CardButton("Classic", style == 0) { style = 0 }
                    CardButton("Light", style == 1) { style = 1 }
                    CardButton("Glass", style == 2) { style = 2 }
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    "${info.title} • ${info.artist}",
                    color = Color.LightGray,
                    fontSize = 13.sp,
                    maxLines = 1
                )
                if (status.isNotEmpty()) Text(status, color = Color(0xFF9EE493), fontSize = 12.sp)

                Spacer(Modifier.height(8.dp))
                Button(
                    enabled = photo != null && song != null,
                    onClick = {
                        val out = savePreviewPng(context, photo, cover, info, style)
                        if (out != null) {
                            shareImage(context, out)
                            status = "Card image created and ready to share"
                        } else {
                            status = "Could not create image"
                        }
                    }
                ) { Text("Create & Share Status Card") }

                Spacer(Modifier.height(6.dp))
                Text(
                    "The selected local audio remains on your phone; this version exports the visual card.",
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun CardButton(label: String, selected: Boolean, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = if (selected) Color.White else Color.LightGray
        )
    ) { Text(label) }
}

@Composable
fun StatusPreview(
    photo: Uri?,
    cover: Bitmap?,
    info: SongInfo,
    style: Int
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val photoBitmap = remember(photo) {
        photo?.let { loadBitmap(context.contentResolver, it) }
    }
    Box(
        Modifier.fillMaxWidth().aspectRatio(9f / 16f)
            .clip(RoundedCornerShape(22.dp)).background(Color(0xFF222222))
    ) {
        if (photoBitmap != null) {
            Image(
                bitmap = photoBitmap.asImageBitmap(),
                contentDescription = "Selected photo",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Choose a photo", color = Color.Gray)
            }
        }
        MusicCard(
            info = info,
            cover = cover,
            style = style,
            modifier = Modifier.align(Alignment.BottomCenter).padding(14.dp)
        )
    }
}

@Composable
fun MusicCard(info: SongInfo, cover: Bitmap?, style: Int, modifier: Modifier) {
    val bg = when(style) {
        0 -> Color(0xE6111111)
        1 -> Color(0xE6F5F5F5)
        else -> Color(0xB8222222)
    }
    val fg = if (style == 1) Color.Black else Color.White
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(bg).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (cover != null) {
            Image(
                bitmap = cover.asImageBitmap(),
                contentDescription = "Album art",
                Modifier.size(54.dp).clip(RoundedCornerShape(10.dp)),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(
                Modifier.size(54.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF444444)),
                contentAlignment = Alignment.Center
            ) { Text("♪", color = fg, fontSize = 25.sp) }
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(info.title.ifBlank { "Unknown title" }, color = fg,
                fontWeight = FontWeight.Bold, maxLines = 1)
            Text(info.artist.ifBlank { "Unknown artist" }, color = fg.copy(alpha = .72f),
                fontSize = 12.sp, maxLines = 1)
            Spacer(Modifier.height(5.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("0:00", color = fg.copy(alpha = .7f), fontSize = 9.sp)
                Spacer(Modifier.width(5.dp))
                Box(Modifier.weight(1f).height(3.dp).clip(RoundedCornerShape(3.dp))
                    .background(fg.copy(alpha = .35f)))
                Spacer(Modifier.width(5.dp))
                Text(formatDuration(info.durationMs), color = fg.copy(alpha = .7f), fontSize = 9.sp)
            }
        }
        Spacer(Modifier.width(8.dp))
        Text("▶", color = fg, fontSize = 18.sp)
    }
}

fun readSongInfo(resolver: ContentResolver, uri: Uri): SongInfo {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(resolver.openAssetFileDescriptor(uri, "r")?.fileDescriptor)
        SongInfo(
            title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: "Unknown title",
            artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: "Unknown artist",
            album = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: "",
            durationMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        )
    } catch (_: Exception) {
        SongInfo()
    } finally { r.release() }
}

fun extractAlbumArt(resolver: ContentResolver, uri: Uri): Bitmap? {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(resolver.openAssetFileDescriptor(uri, "r")?.fileDescriptor)
        r.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
    } catch (_: Exception) { null }
    finally { r.release() }
}

fun loadBitmap(resolver: ContentResolver, uri: Uri): Bitmap? =
    try { resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } }
    catch (_: Exception) { null }

fun formatDuration(ms: Long): String {
    val sec = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(sec / 60, sec % 60)
}

fun savePreviewPng(
    context: Context,
    photo: Uri?,
    cover: Bitmap?,
    info: SongInfo,
    style: Int
): Uri? {
    val photoBmp = photo?.let { loadBitmap(context.contentResolver, it) } ?: return null
    val w = 1080
    val h = 1920
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(out)
    val scale = maxOf(w.toFloat() / photoBmp.width, h.toFloat() / photoBmp.height)
    val sw = photoBmp.width * scale
    val sh = photoBmp.height * scale
    val left = (w - sw) / 2f
    val top = (h - sh) / 2f
    canvas.drawBitmap(photoBmp, null, android.graphics.RectF(left, top, left + sw, top + sh), null)

    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    val cardLeft = 55f
    val cardRight = 1025f
    val cardTop = 1510f
    val cardBottom = 1810f
    paint.color = when(style) {
        0 -> android.graphics.Color.argb(230, 17, 17, 17)
        1 -> android.graphics.Color.argb(230, 245, 245, 245)
        else -> android.graphics.Color.argb(185, 34, 34, 34)
    }
    canvas.drawRoundRect(cardLeft, cardTop, cardRight, cardBottom, 42f, 42f, paint)

    val fg = if(style == 1) android.graphics.Color.BLACK else android.graphics.Color.WHITE
    val art = cover ?: Bitmap.createBitmap(1,1,Bitmap.Config.ARGB_8888).apply { eraseColor(android.graphics.Color.DKGRAY) }
    canvas.drawBitmap(art, null, android.graphics.RectF(85f,1540f,255f,1710f), paint)

    paint.color = fg
    paint.textSize = 46f
    paint.typeface = android.graphics.Typeface.DEFAULT_BOLD
    canvas.drawText(info.title.ifBlank{"Unknown title"}, 285f, 1610f, paint)
    paint.textSize = 34f
    paint.typeface = android.graphics.Typeface.DEFAULT
    canvas.drawText(info.artist.ifBlank{"Unknown artist"}, 285f, 1660f, paint)
    paint.strokeWidth = 7f
    canvas.drawLine(285f, 1715f, 925f, 1715f, paint)
    paint.textSize = 27f
    canvas.drawText("0:00", 285f, 1760f, paint)
    canvas.drawText(formatDuration(info.durationMs), 850f, 1760f, paint)
    paint.textSize = 46f
    canvas.drawText("▶", 950f, 1655f, paint)

    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "music_status_${System.currentTimeMillis()}.png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MusicStatusCard")
    }
    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        ?: return null
    context.contentResolver.openOutputStream(uri)?.use { outStream: OutputStream ->
        out.compress(Bitmap.CompressFormat.PNG, 100, outStream)
    } ?: return null
    return uri
}

fun shareImage(context: Context, uri: Uri) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "image/png"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share status card"))
}
